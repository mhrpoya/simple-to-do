# Simple-To-Do
A simple-to-use checklist plugin for VS Code
